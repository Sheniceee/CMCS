# CMCS - Contract Monthly Claim System (prototype)

This is a ready-to-run ASP.NET Core MVC prototype (plaintext passwords for demo). See CMCS folder.

Commands:

```
cd CMCS
dotnet restore
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
dotnet run
```

Sample logins: lect2@example.com / pass123 (Lecturer), coord@example.com / pass123 (Coordinator)
