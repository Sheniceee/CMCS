using CMCS.Data;
using CMCS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMCS.Controllers
{
    [Authorize]
    public class CoordinatorController : Controller
    {
        private readonly CmcsContext _db;
        public CoordinatorController(CmcsContext db) { _db = db; }

        public async Task<IActionResult> Pending()
        {
            var claims = await _db.Claims.Include(c => c.Lecturer).Where(c => c.Status == ClaimStatus.Submitted || c.Status == ClaimStatus.ChangesRequested).OrderBy(c => c.SubmittedDate).ToListAsync();
            return View(claims);
        }

        [HttpGet]
        public async Task<IActionResult> Review(int id)
        {
            var claim = await _db.Claims.Include(c => c.Lecturer).Include(c => c.Lines).Include(c => c.Documents).FirstOrDefaultAsync(c => c.Id == id);
            if (claim == null) return NotFound();
            return View(claim);
        }

        [HttpPost]
        public async Task<IActionResult> Approve(int id, string comment)
        {
            var claim = await _db.Claims.FirstOrDefaultAsync(c => c.Id == id);
            if (claim == null) return NotFound();
            claim.Status = ClaimStatus.Approved;
            claim.ReviewedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Pending));
        }

        [HttpPost]
        public async Task<IActionResult> RequestChanges(int id, string comment)
        {
            var claim = await _db.Claims.FirstOrDefaultAsync(c => c.Id == id);
            if (claim == null) return NotFound();
            claim.Status = ClaimStatus.ChangesRequested;
            claim.ReviewedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Pending));
        }
    }
}