using CMCS.Data;
using CMCS.Models;
using CMCS.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMCS.Controllers
{
    [Authorize]
    public class LecturerController : Controller
    {
        private readonly CmcsContext _db;
        private readonly IWebHostEnvironment _env;
        public LecturerController(CmcsContext db, IWebHostEnvironment env) { _db = db; _env = env; }

        private int CurrentUserId => int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value);

        public async Task<IActionResult> Dashboard()
        {
            var claims = await _db.Claims.Include(c => c.Lines).Where(c => c.LecturerId == CurrentUserId).OrderByDescending(c => c.SubmittedDate).ToListAsync();
            return View(claims);
        }

        [HttpGet]
        public IActionResult CreateClaim() => View(new CreateClaimViewModel());

        [HttpPost]
        public async Task<IActionResult> CreateClaim(CreateClaimViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);
            var claim = new Claim
            {
                LecturerId = CurrentUserId,
                Month = vm.Month,
                Year = vm.Year,
                SubmittedDate = DateTime.UtcNow,
                Status = ClaimStatus.Submitted
            };
            foreach (var l in vm.Lines)
                claim.Lines.Add(new ClaimLine { ActivityDescription = l.Activity, HoursWorked = l.Hours, HourlyRate = l.HourlyRate });

            claim.TotalAmount = claim.Lines.Sum(x => x.LineTotal);
            _db.Claims.Add(claim);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Dashboard));
        }

        [HttpGet]
        public async Task<IActionResult> ViewClaim(int id)
        {
            var claim = await _db.Claims.Include(c => c.Lines).Include(c => c.Documents).FirstOrDefaultAsync(c => c.Id == id && c.LecturerId == CurrentUserId);
            if (claim == null) return NotFound();
            return View(claim);
        }

        [HttpPost]
        public async Task<IActionResult> UploadDocs(int claimId, IFormFile[] files)
        {
            var claim = await _db.Claims.FirstOrDefaultAsync(c => c.Id == claimId && c.LecturerId == CurrentUserId);
            if (claim == null) return NotFound();

            var uploadDir = Path.Combine(_env.WebRootPath, "uploads");
            if (!Directory.Exists(uploadDir)) Directory.CreateDirectory(uploadDir);

            foreach (var f in files)
            {
                var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(f.FileName)}";
                var path = Path.Combine(uploadDir, fileName);
                using (var stream = new FileStream(path, FileMode.Create)) await f.CopyToAsync(stream);
                claim.Documents.Add(new Document { FileName = f.FileName, FilePath = $"/uploads/{fileName}", UploadedDate = DateTime.UtcNow });
            }
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(ViewClaim), new { id = claimId });
        }
    }
}