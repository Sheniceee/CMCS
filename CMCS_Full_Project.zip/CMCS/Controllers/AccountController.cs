using CMCS.Data;
using CMCS.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace CMCS.Controllers
{
    public class AccountController : Controller
    {
        private readonly CmcsContext _db;
        public AccountController(CmcsContext db) { _db = db; }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password, string role)
        {
            if (string.IsNullOrEmpty(email)) { ModelState.AddModelError("", "Enter email"); return View(); }

            var user = _db.Lecturers.FirstOrDefault(u => u.Email == email);
            if (user == null)
            {
                // create a simple user for prototype
                user = new Lecturer { FirstName = email.Split('@')[0], LastName = "", Email = email, Password = password ?? "pass123", Role = Enum.Parse<RoleType>(role) };
                _db.Lecturers.Add(user);
                _db.SaveChanges();
            }
            else
            {
                if (user.Password != (password ?? ""))
                {
                    ModelState.AddModelError("", "Invalid credentials");
                    return View();
                }
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.FullName),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim("role", user.Role.ToString())
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            if (user.Role == RoleType.Lecturer) return RedirectToAction("Dashboard", "Lecturer");
            return RedirectToAction("Pending", "Coordinator");
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction(nameof(Login));
        }
    }
}