using System.ComponentModel.DataAnnotations;

namespace CMCS.ViewModels
{
    public class ClaimLineViewModel
    {
        public string Activity { get; set; }
        public decimal Hours { get; set; }
        public decimal HourlyRate { get; set; }
    }

    public class CreateClaimViewModel
    {
        [Range(1,12)] public int Month { get; set; }
        public int Year { get; set; } = DateTime.UtcNow.Year;
        public List<ClaimLineViewModel> Lines { get; set; } = new List<ClaimLineViewModel>();
    }
}