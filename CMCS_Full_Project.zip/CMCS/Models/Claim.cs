using System.ComponentModel.DataAnnotations.Schema;

namespace CMCS.Models
{
    public enum ClaimStatus { Draft, Submitted, ChangesRequested, Approved, Rejected }

    public class Claim
    {
        public int Id { get; set; }
        public int LecturerId { get; set; }
        public Lecturer Lecturer { get; set; }

        public int Month { get; set; }
        public int Year { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        public ClaimStatus Status { get; set; } = ClaimStatus.Draft;
        public DateTime SubmittedDate { get; set; }
        public DateTime? ReviewedDate { get; set; }

        public ICollection<ClaimLine> Lines { get; set; } = new List<ClaimLine>();
        public ICollection<Document> Documents { get; set; } = new List<Document>();
    }
}