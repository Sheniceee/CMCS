namespace CMCS.Models
{
    public class ClaimLine
    {
        public int Id { get; set; }
        public int ClaimId { get; set; }
        public Claim Claim { get; set; }

        public string ActivityDescription { get; set; }
        public decimal HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal LineTotal => HoursWorked * HourlyRate;
    }
}