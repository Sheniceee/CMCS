using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public enum RoleType { Lecturer, Coordinator, AcademicManager }

    public class Lecturer
    {
        public int Id { get; set; }
        [Required] public string FirstName { get; set; }
        [Required] public string LastName { get; set; }
        [Required] public string Email { get; set; }
        // Plaintext password for prototype only
        public string Password { get; set; }
        public RoleType Role { get; set; } = RoleType.Lecturer;

        public string FullName => $"{FirstName} {LastName}";
        public ICollection<Claim> Claims { get; set; } = new List<Claim>();
    }
}