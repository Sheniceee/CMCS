using CMCS.Models;

namespace CMCS.Data
{
    public static class DataSeeder
    {
        public static void Seed(CmcsContext db)
        {
            if (!db.Lecturers.Any())
            {
                var lect1 = new Lecturer { FirstName = "Lecturer", LastName = "One", Email = "lect1@example.com", Password = "pass123", Role = RoleType.Lecturer };
                var lect2 = new Lecturer { FirstName = "Dr. A.", LastName = "Smith", Email = "lect2@example.com", Password = "pass123", Role = RoleType.Lecturer };
                var coord = new Lecturer { FirstName = "Programme", LastName = "Coordinator", Email = "coord@example.com", Password = "pass123", Role = RoleType.Coordinator };

                db.Lecturers.AddRange(lect1, lect2, coord);
                db.SaveChanges();

                var claim = new Claim {
                    LecturerId = lect2.Id,
                    Month = 8,
                    Year = 2025,
                    Status = ClaimStatus.Submitted,
                    SubmittedDate = DateTime.UtcNow,
                    TotalAmount = 4800 + 1600
                };
                db.Claims.Add(claim);
                db.SaveChanges();

                db.ClaimLines.AddRange(
                    new ClaimLine { ClaimId = claim.Id, ActivityDescription = "Lecturing", HoursWorked = 30, HourlyRate = 160 },
                    new ClaimLine { ClaimId = claim.Id, ActivityDescription = "Marking", HoursWorked = 10, HourlyRate = 160 }
                );
                db.SaveChanges();
            }
        }
    }
}