using CMCS.Models;
using Microsoft.EntityFrameworkCore;

namespace CMCS.Data
{
    public class CmcsContext : DbContext
    {
        public CmcsContext(DbContextOptions<CmcsContext> options) : base(options) { }

        public DbSet<Lecturer> Lecturers { get; set; }
        public DbSet<Claim> Claims { get; set; }
        public DbSet<ClaimLine> ClaimLines { get; set; }
        public DbSet<Document> Documents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Lecturer>().HasIndex(l => l.Email).IsUnique();
            modelBuilder.Entity<Claim>().HasMany(c => c.Lines).WithOne(l => l.Claim).HasForeignKey(l => l.ClaimId);
            modelBuilder.Entity<Claim>().HasMany(c => c.Documents).WithOne(d => d.Claim).HasForeignKey(d => d.ClaimId);
        }
    }
}